<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="css/sidebar-1.css?h=c234f943e0d37ce61012bee59767270b">
    <link rel="stylesheet" href="css/sidebar.css?h=f606b4c1a89dd6df54db0553f4f7d174">
    <link rel="stylesheet" href="css/styles.css?h=d41d8cd98f00b204e9800998ecf8427e">
</head>

<body><div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Admin DashBoard</h3>
                    <strong>AD</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                         <li>
                        <a href="addproduct.php">
                            <i class="glyphicon glyphicon-link"></i>
                            Add Product
                        </a>
                    </li>
                    
                    <li>
                        <a href='chat.php'>
                            <i class="glyphicon glyphicon-briefcase"></i>
                            Chat
                        </a>
                         <li>
                        <a href="order.php">
                            <i class="glyphicon glyphicon-link"></i>
                            View Orders
                        </a>
                    </li>
                    <li>
                        <a href="updateproduct.php">
                            <i class="glyphicon glyphicon-link"></i>
                            Update Product
                        </a>
                    </li>
                    <li>
                        <a href="user.php">
                            <i class="glyphicon glyphicon-paperclip"></i>
                            All User
                        </a>
                    </li>
                    <li>
                        <a href="revenue.php">
                            <i class="glyphicon glyphicon-send"></i>
                            Total Revenue
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Page Content Holder -->
            <div id="content">

                <nav class="navbar navbar-default">
                    <div class="container-fluid">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </nav>
            </div>
        </div>





        <!-- jQuery CDN -->
         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
         </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
</body>

</html>