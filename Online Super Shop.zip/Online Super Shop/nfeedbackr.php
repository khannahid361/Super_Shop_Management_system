<?php

error_reporting(0);

?>
<?php



include "header.php";






?>
<?php
//sever connection
$server="localhost";
$username="root";
$password="";
$database="ecommerce";

$conn= mysqli_connect($server,$username,$password,$database);

		if($conn)
		{
			echo "";
		}
		else
		{
			echo "failed";
		}

//user verification
session_start();
	  $userprofilo = $_SESSION['email'];
	  if($userprofilo==true)
	  {
		 
	  }
	  else
	  {
		     		header('location:logout.php');

	  }

                             
                            if(isset($_SESSION["uid"])){
                                $sql = "SELECT first_name FROM user_info WHERE user_id='$_SESSION[uid]'";
                                $query = mysqli_query($con,$sql);
                                $row=mysqli_fetch_array($query);
                                
                                echo '
                               ';

                            }else{ 
                                echo '';
								
                                
                            }
                                       


//massage system		
if(isset($_POST['submit'])) 
{ 
      $myusernames =$_POST['usernames'];
      $mymessages =$_POST['messages'];
  $query = "INSERT INTO FEEDBACKS VALUES ('$myusernames','$mymessages')";
      $result = mysqli_query($conn,$query);
	  echo $result;
	  if($result)
	{
		echo ":data inserted";
		header('location:index.php');
	}
	else
	{
		echo "failed";
	}
	  
}

?>
<html>
   
   <head>
      <title></title>
	  <style>
body{
      ;
	
}
input[type=submit]{
	width: 80%;
    padding: 10px;
    margin: 2px 18px 4px 25px;
    display: inline-block;
    border: none;
	border-radius:6px 6px 6px 6px;
    background: white;

}
input[type=submit]:hover{
	width: 80%;
    padding: 10px;
    margin: 2px 18px 4px 25px;
    display: inline-block;
    border: none;
	border-radius:6px 6px 6px 6px;
    background: #c1bbbb;
}
input[type=text], input[type=password] {
    width: 80%;
    padding: 10px;
    margin: 2px 18px 4px 25px;
    display: inline-block;
    border: none;
	border-radius:6px 6px 6px 6px;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
  border-bottom: 2px solid #828080;
}	



.figure_innerbox2{
	background-image: url(videos/Navy-Blue-Desktop-Backgrounds-hd-4k-high-definition-windows-10-mac.apple-colourful-images-download-wallpaper-free-2560x1600-768x480.jpg);
    color: #33b4bb;
    /* background-color: #080808bd; */
    padding: 46px;
    padding-bottom: 200px;
    width: 370px;
    margin-top: 61px;
    border-radius: 6px 6px 6px 6px;
    transparent: .5%;
    /* box-shadow: 0px 5px 80px #bbbbbb; */
    border: 1px solid #bbbbbb;
    margin-left: 400px;
    height: 80px;
    margin: auto;
}
.texts{
    text-decoration: none;
    color: white;
    margin: 2px 18px 4px 25px;
}
.images{
    width: 80px;
    height: 80px;
    border-radius: 50%;
    margin-top: -16px;
    margin-left: 130px;
	box-shadow: 0px 5px 4px #13151b;
}	
	</style>
   </head>
   <body>
   <br>
   <br>
   <div class="figure_innerbox2">

<form class="form_b" action ="" method ="post">
                  <input type ="text" name ="usernames" value="<?php echo $row["first_name"];  ?>" readonly="readonly"/><br /><br />
                 <input type ="text" name ="messages" value="" placeholder="Enter your Massage" required /><br/><br />
                  <input type = "submit" name="submit" value = "submit"/><br />
               </form>
			   </div>
	</body>
	
 </html>
 <br>
 <br>
 <?php

include "footer.php";

?>
