<?php 
include "db.php";
include "admin.php";
echo "hello chat";
?>

