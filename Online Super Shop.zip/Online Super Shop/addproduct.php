<?php 
include "db.php";
include "admin.php";

?>
<form>

